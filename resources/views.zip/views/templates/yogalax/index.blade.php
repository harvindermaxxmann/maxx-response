<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Landing Page Title</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Work+Sans:100,200,300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="{{ asset('landing-assets/yogalax/css/open-iconic-bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{ asset('landing-assets/yogalax/css/animate.css')}}">
    
    <link rel="stylesheet" href="{{ asset('landing-assets/yogalax/css/owl.carousel.min.css')}}">
    <link rel="stylesheet" href="{{ asset('landing-assets/yogalax/css/owl.theme.default.min.css')}}">
    <link rel="stylesheet" href="{{ asset('landing-assets/yogalax/css/magnific-popup.css')}}">

    <link rel="stylesheet" href="{{ asset('landing-assets/yogalax/css/aos.css')}}">

    <link rel="stylesheet" href="{{ asset('landing-assets/yogalax/css/ionicons.min.css')}}">

    <link rel="stylesheet" href="{{ asset('landing-assets/yogalax/css/bootstrap-datepicker.css')}}">
    <link rel="stylesheet" href="{{ asset('landing-assets/yogalax/css/jquery.timepicker.css')}}">

    
    <link rel="stylesheet" href="{{ asset('landing-assets/yogalax/css/flaticon.css')}}">
    <link rel="stylesheet" href="{{ asset('landing-assets/yogalax/css/icomoon.css')}}">
    <link rel="stylesheet" href="{{ asset('landing-assets/yogalax/css/style.css')}}">
  </head>
  <body>
  	<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="javascript:;"><span class="flaticon-lotus"></span>Yogalax</a>	      
		  </div>
	  </nav>
    <!-- END nav -->

    <section class="hero-wrap js-fullheight" style="background-image: url('/landing-assets/yogalax/images/bg_2.jpg');">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-start">
          <div class="col-md-8 ftco-animate">
            <h1 class="typewrite mb-3" data-period="4000" data-type='[ "Inspiration For Joyful Living.", "Effective Therapy Against Stress.", "Flexibility is A Second Power."]'>
              <span class="wrap"></span>
            </h1>
            <h2 class="mb-5">Do Yoga today for a better tomorrow</h2>
            <p><a href="#" class="btn btn-primary p-3 px-4">15 Day Free Trial</a></p>
          </div>
        </div>
      </div>
    </section>
		
		<section class="ftco-section ftco-intro" style="background-image: url('/landing-assets/yogalax/images/intro.jpg');">
			<div class="container">
				<div class="row justify-content-end">
					<div class="col-md-6">
						<div class="heading-section ftco-animate">
	            <h2 class="mb-4">Why You Should Go To Yoga</h2>
	          </div>
	          <p class="ftco-animate">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
	          <ul class="mt-5 do-list">
	          	<li class="ftco-animate"><a href="#"><span class="ion-ios-checkmark-circle mr-3"></span>Yoga boosts brain power</a></li>
	          	<li class="ftco-animate"><a href="#"><span class="ion-ios-checkmark-circle mr-3"></span>Yoga helps you to breathe better</a></li>
	          	<li class="ftco-animate"><a href="#"><span class="ion-ios-checkmark-circle mr-3"></span>Yoga improves your strength</a></li>
	          	<li class="ftco-animate"><a href="#"><span class="ion-ios-checkmark-circle mr-3"></span>Yoga helps you to focus</a></li>
	          	<li class="ftco-animate"><a href="#"><span class="ion-ios-checkmark-circle mr-3"></span>Yoga helps give meaning to your day</a></li>
	          </ul>
					</div>
				</div>
			</div>
		</section>
    
    <section class="ftco-section ftco-section-services bg-light">
    	<div class="container">
    		<div class="row">
    			<div class="col-md-3">
						<div class="services ftco-animate">
							<div class="icon d-flex justify-content-center align-items-center">
								<span class="flaticon-like"></span>
							</div>
							<div class="text mt-4">
								<h3>Healthy Lifestyle</h3>
								<p>A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country</p>
							</div>
						</div>
					</div>
					<div class="col-md-3">
						<div class="services ftco-animate">
							<div class="icon d-flex justify-content-center align-items-center">
								<span class="flaticon-lotus"></span>
							</div>
							<div class="text mt-4">
								<h3>Body &amp; Mind Balance</h3>
								<p>A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country</p>
							</div>
						</div>
					</div>
					<div class="col-md-3">
						<div class="services ftco-animate">
							<div class="icon d-flex justify-content-center align-items-center">
								<span class="flaticon-meditation"></span>
							</div>
							<div class="text mt-4">
								<h3>Meditation Practice</h3>
								<p>A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country</p>
							</div>
						</div>
					</div>
					<div class="col-md-3">
						<div class="services ftco-animate">
							<div class="icon d-flex justify-content-center align-items-center">
								<span class="flaticon-lotus-1"></span>
							</div>
							<div class="text mt-4">
								<h3>Edeology</h3>
								<p>A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country</p>
							</div>
						</div>
					</div>
				</div>
    	</div>
    </section>

	  <section class="ftco-section">
	  	<div class="container">
	  		<div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-12 heading-section ftco-animate text-center">
            <h3 class="subheading">Yoga Classes</h3>
            <h2 class="mb-1">Choose Your Level &amp; Focus</h2>
          </div>
        </div>
        <div class="row no-gutters">
        	<div class="col-md-6 col-lg-4">
        		<div class="package-program ftco-animate">
        			<a href="#" class="img d-flex justify-content-center align-items-center" style="background-image: url('/landing-assets/yogalax/images/program-1.jpg');">
        				<div class="text p-5 text-center">
	        				<h3>Group Lessons</h3>
	        				<p>A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
	        			</div>
        			</a>
        		</div>
        	</div>
        	<div class="col-md-6 col-lg-4">
        		<div class="package-program ftco-animate">
        			<a href="#" class="img d-flex justify-content-center align-items-center" style="background-image: url('/landing-assets/yogalax/images/program-2.jpg');">
        				<div class="text p-5 text-center">
	        				<h3>Yoga For Beginners</h3>
	        				<p>A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
	        			</div>
        			</a>
        		</div>
        	</div>
        	<div class="col-md-6 col-lg-4">
        		<div class="package-program ftco-animate">
        			<a href="#" class="img d-flex justify-content-center align-items-center" style="background-image: url('/landing-assets/yogalax/images/program-3.jpg');">
        				<div class="text p-5 text-center">
	        				<h3>Yoga For Pregnant</h3>
	        				<p>A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
	        			</div>
        			</a>
        		</div>
        	</div>
        	<div class="col-md-6 col-lg-4">
        		<div class="package-program ftco-animate">
        			<a href="#" class="img d-flex justify-content-center align-items-center" style="background-image: url('/landing-assets/yogalax/images/program-4.jpg');">
        				<div class="text p-5 text-center">
	        				<h3>Yoga For Couples</h3>
	        				<p>A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
	        			</div>
        			</a>
        		</div>
        	</div>
        	<div class="col-md-6 col-lg-4">
        		<div class="package-program ftco-animate">
        			<a href="#" class="img d-flex justify-content-center align-items-center" style="background-image: url('/landing-assets/yogalax/images/program-5.jpg');">
        				<div class="text p-5 text-center">
	        				<h3>Bikram Yoga</h3>
	        				<p>A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
	        			</div>
        			</a>
        		</div>
        	</div>
        	<div class="col-md-6 col-lg-4">
        		<div class="package-program ftco-animate">
        			<a href="#" class="img d-flex justify-content-center align-items-center" style="background-image: url('/landing-assets/yogalax/images/program-6.jpg');">
        				<div class="text p-5 text-center">
	        				<h3>Yoga Barre</h3>
	        				<p>A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
	        			</div>
        			</a>
        		</div>
        	</div>
        </div>
	  	</div>
	  </section>


    <section class="ftco-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 heading-section ftco-animate text-center">
            <h3 class="subheading">Pricing Tables</h3>
            <h2 class="mb-1">Membership Cards</h2>
          </div>
        </div>
        <div class="row">
	        <div class="col-md-4 ftco-animate">
	          <div class="block-7">
	            <div class="text-center">
	            <h2 class="heading">Year Card</h2>
	            <span class="price"><sup>$</sup> <span class="number">449</span></span>
	            <span class="excerpt d-block">For 1 Year</span>
	            
	            <h3 class="heading-2 my-4">Enjoy All The Features</h3>
	            
	            <ul class="pricing-text mb-5">
	              <li>Onetime Access To All Club</li>
	              <li>Group Trainer</li>
	              <li>Book A Group Class</li>
	              <li>Fitness Orientation</li>
	            </ul>

	            <a href="#" class="btn btn-primary d-block px-2 py-4">Get Started</a>
	            </div>
	          </div>
	        </div>
	        <div class="col-md-4 ftco-animate">
	          <div class="block-7">
	            <div class="text-center">
	            <h2 class="heading">Monthly Card</h2>
	            <span class="price"><sup>$</sup> <span class="number">200</span></span>
	            <span class="excerpt d-block">For 1 Month</span>
	            
	            <h3 class="heading-2 my-4">Enjoy All The Features</h3>
	            
	            <ul class="pricing-text mb-5">
	              <li>Group Classes</li>
	              <li>Discuss Fitness Goals</li>
	              <li>Group Trainer</li>
	              <li>Fitness Orientation</li>
	            </ul>

	            <a href="#" class="btn btn-primary d-block px-2 py-4">Get Started</a>
	            </div>
	          </div>
	        </div>
	        <div class="col-md-4 ftco-animate">
	          <div class="block-7">
	            <div class="text-center">
	            <h2 class="heading">Weekly Card</h2>
	            <span class="price"><sup>$</sup> <span class="number">85</span></span>
	            <span class="excerpt d-block">For 1 Week</span>
	            
	            <h3 class="heading-2 my-4">Enjoy All The Features</h3>
	            
	            <ul class="pricing-text mb-5">
	              <li>Group Classes</li>
	              <li>Discuss Fitness Goals</li>
	              <li>Group Trainer</li>
	              <li>Fitness Orientation</li>
	            </ul>

	            <a href="#" class="btn btn-primary d-block px-2 py-4">Get Started</a>
	            </div>
	          </div>
	        </div>
	      </div>
      </div>
    </section>


    <section class="ftco-section testimony-section">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 heading-section ftco-animate text-center">
            <h3 class="subheading">Testimony</h3>
            <h2 class="mb-1">Successful Stories</h2>
          </div>
        </div>
        <div class="row ftco-animate">
          <div class="col-md-12">
            <div class="carousel-testimony owl-carousel">
              <div class="item">
                <div class="testimony-wrap p-4 pb-5">
                  <div class="text">
                  	<div class="line pl-5">
	                    <p class="mb-4 pb-1">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
	                    <span class="quote d-flex align-items-center justify-content-center">
	                      <i class="icon-quote-left"></i>
	                    </span>
	                  </div>
                    <div class="d-flex align-items-center">
                    	<div class="user-img" style="background-image: url('/landing-assets/yogalax/images/person_1.jpg)">
		                  </div>
		                  <div class="ml-4">
		                  	<p class="name">Gabby Smith</p>
		                    <span class="position">Customer</span>
		                  </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap p-4 pb-5">
                  <div class="text">
                    <div class="line pl-5">
	                    <p class="mb-4 pb-1">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
	                    <span class="quote d-flex align-items-center justify-content-center">
	                      <i class="icon-quote-left"></i>
	                    </span>
	                  </div>

                    <div class="d-flex align-items-center">
                    	<div class="user-img" style="background-image: url('/landing-assets/yogalax/images/person_2.jpg)">
		                  </div>
		                  <div class="ml-4">
		                  	<p class="name">Floyd Weather</p>
		                    <span class="position">Customer</span>
		                  </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap p-4 pb-5">
                  <div class="text">
                    <div class="line pl-5">
	                    <p class="mb-4 pb-1">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
	                    <span class="quote d-flex align-items-center justify-content-center">
	                      <i class="icon-quote-left"></i>
	                    </span>
	                  </div>

                    <div class="d-flex align-items-center">
                    	<div class="user-img" style="background-image: url('/landing-assets/yogalax/images/person_3.jpg)">
		                  </div>
		                  <div class="ml-4">
		                  	<p class="name">James Dee</p>
		                    <span class="position">Customer</span>
		                  </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap p-4 pb-5">
                  <div class="text">
                    <div class="line pl-5">
	                    <p class="mb-4 pb-1">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
	                    <span class="quote d-flex align-items-center justify-content-center">
	                      <i class="icon-quote-left"></i>
	                    </span>
	                  </div>

                    <div class="d-flex align-items-center">
                    	<div class="user-img" style="background-image: url('/landing-assets/yogalax/images/person_4.jpg)">
		                  </div>
		                  <div class="ml-4">
		                  	<p class="name">Lance Roger</p>
		                    <span class="position">Customer</span>
		                  </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap p-4 pb-5">
                  <div class="text">
                    <div class="line pl-5">
	                    <p class="mb-4 pb-1">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
	                    <span class="quote d-flex align-items-center justify-content-center">
	                      <i class="icon-quote-left"></i>
	                    </span>
	                  </div>

                    <div class="d-flex align-items-center">
                    	<div class="user-img" style="background-image: url('/landing-assets/yogalax/images/person_2.jpg)">
		                  </div>
		                  <div class="ml-4">
		                  	<p class="name">Kenny Bufer</p>
		                    <span class="position">Customer</span>
		                  </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-counter ftco-bg-dark img" id="section-counter" style="background-image: url('/landing-assets/yogalax/images/bg_3.jpg');" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
      <div class="container">
        <div class="row justify-content-center">
        	<div class="col-md-10">
        		<div class="row">
		          <div class="col-md-6 col-lg-3 d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18 text-center">
		              <div class="text">
		              	<strong class="number" data-number="5000">0</strong>
		              	<span>Happy Customers</span>
		              </div>
		            </div>
		          </div>
		          <div class="col-md-6 col-lg-3 d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18 text-center">
		              <div class="text">
		              	<strong class="number" data-number="4560">0</strong>
		              	<span>Yoga Workshops</span>
		              </div>
		            </div>
		          </div>
		          <div class="col-md-6 col-lg-3 d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18 text-center">
		              <div class="text">
		              	<strong class="number" data-number="570">0</strong>
		              	<span>Years of Experience</span>
		              </div>
		            </div>
		          </div>
		          <div class="col-md-6 col-lg-3 d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18 text-center">
		              <div class="text">
		              	<strong class="number" data-number="900">0</strong>
		              	<span>Lesson Conducted</span>
		              </div>
		            </div>
		          </div>
		        </div>
		      </div>
        </div>
      </div>
    </section>    

		<section class="ftco-gallery ftco-section">
    	<div class="container">
    		<div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 heading-section ftco-animate text-center">
            <h3 class="subheading">Gallery</h3>
            <h2 class="mb-1">See the latest photos</h2>
          </div>
        </div>
    		<div class="row">
					<div class="col-md-3 ftco-animate">
						<a href="'landing-assets/yogalax/images/gallery-1.jpg" class="gallery image-popup img d-flex align-items-center" style="background-image: url('/landing-assets/yogalax/images/gallery-1.jpg');">
							<div class="icon mb-4 d-flex align-items-center justify-content-center">
    						<span class="icon-instagram"></span>
    					</div>
						</a>
					</div>
					<div class="col-md-3 ftco-animate">
						<a href="'landing-assets/yogalax/images/gallery-2.jpg" class="gallery image-popup img d-flex align-items-center" style="background-image: url('/landing-assets/yogalax/images/gallery-2.jpg');">
							<div class="icon mb-4 d-flex align-items-center justify-content-center">
    						<span class="icon-instagram"></span>
    					</div>
						</a>
					</div>
					<div class="col-md-3 ftco-animate">
						<a href="'landing-assets/yogalax/images/gallery-3.jpg" class="gallery image-popup img d-flex align-items-center" style="background-image: url('/landing-assets/yogalax/images/gallery-3.jpg');">
							<div class="icon mb-4 d-flex align-items-center justify-content-center">
    						<span class="icon-instagram"></span>
    					</div>
						</a>
					</div>
					<div class="col-md-3 ftco-animate">
						<a href="'landing-assets/yogalax/images/gallery-4.jpg" class="gallery image-popup img d-flex align-items-center" style="background-image: url('/landing-assets/yogalax/images/gallery-4.jpg');">
							<div class="icon mb-4 d-flex align-items-center justify-content-center">
    						<span class="icon-instagram"></span>
    					</div>
						</a>
					</div>
        </div>
    	</div>
    </section>

		

    <footer class="ftco-footer ftco-section img">
    	<div class="overlay"></div>
      <div class="container">
        <div class="row mb-5">
        	<div class="col-lg-3 col-md-6 mb-5 mb-md-5 ftco-animate">
            <div class="ftco-footer-widget mb-4">
              <h1 class="logo">Yogalax</h1>
            </div>
          </div>
          <div class="col-lg col-md-6 mb-5 mb-md-5 ftco-animate">
            <div class="ftco-footer-widget mb-4">
              <h2 class="location">203 Fake St. Mountain View, San Francisco, California, USA</h2>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 mb-5 mb-md-5">
            <div class="ftco-footer-widget mb-4">
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p>
            	Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="{{ asset('landing-assets/yogalax/js/jquery.min.js')}}"></script>
  <script src="{{ asset('landing-assets/yogalax/js/jquery-migrate-3.0.1.min.js')}}"></script>
  <script src="{{ asset('landing-assets/yogalax/js/popper.min.js')}}"></script>
  <script src="{{ asset('landing-assets/yogalax/js/bootstrap.min.js')}}"></script>
  <script src="{{ asset('landing-assets/yogalax/js/jquery.easing.1.3.js')}}"></script>
  <script src="{{ asset('landing-assets/yogalax/js/jquery.waypoints.min.js')}}"></script>
  <script src="{{ asset('landing-assets/yogalax/js/jquery.stellar.min.js')}}"></script>
  <script src="{{ asset('landing-assets/yogalax/js/owl.carousel.min.js')}}"></script>
  <script src="{{ asset('landing-assets/yogalax/js/jquery.magnific-popup.min.js')}}"></script>
  <script src="{{ asset('landing-assets/yogalax/js/aos.js')}}"></script>
  <script src="{{ asset('landing-assets/yogalax/js/jquery.animateNumber.min.js')}}"></script>
  <script src="{{ asset('landing-assets/yogalax/js/bootstrap-datepicker.js')}}"></script>
  <script src="{{ asset('landing-assets/yogalax/js/jquery.timepicker.min.js')}}"></script>
  <script src="{{ asset('landing-assets/yogalax/js/scrollax.min.js')}}"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="{{ asset('landing-assets/yogalax/js/google-map.js')}}"></script>
  <script src="{{ asset('landing-assets/yogalax/js/main.js')}}"></script>
    
  </body>
</html>